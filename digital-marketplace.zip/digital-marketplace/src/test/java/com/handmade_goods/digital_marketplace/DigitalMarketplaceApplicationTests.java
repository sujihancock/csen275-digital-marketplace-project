package com.handmade_goods.digital_marketplace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalMarketplaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
