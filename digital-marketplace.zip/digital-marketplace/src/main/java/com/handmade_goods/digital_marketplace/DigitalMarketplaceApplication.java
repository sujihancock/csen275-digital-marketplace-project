package com.handmade_goods.digital_marketplace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigitalMarketplaceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigitalMarketplaceApplication.class, args);
	}

}
